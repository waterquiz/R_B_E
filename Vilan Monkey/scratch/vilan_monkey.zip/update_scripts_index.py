import os
import json

scripts_dir = os.path.join(os.path.dirname(__file__), 'scripts')
index_file = os.path.join(scripts_dir, 'index.json')

if os.path.exists(scripts_dir):
    js_files = [
        f for f in os.listdir(scripts_dir)
        if f.endswith('.js') and f != 'index.json'
    ]
    with open(index_file, 'w', encoding='utf-8') as f:
        json.dump(js_files, f, indent=2)
    print(f"Updated {index_file} with {len(js_files)} scripts:")
    for file in js_files:
        print(f" - {file}")
