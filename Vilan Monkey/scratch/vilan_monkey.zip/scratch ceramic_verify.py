with open('popup/index.js', 'r', encoding='utf-8', errors='ignore') as f:
    js_text = f.read()
    print("header in popup/index.js:", "header" in js_text)
    print("plus-icon-container in popup/index.js:", "plus-icon-container" in js_text)
    print("search-container in popup/index.js:", "search-container" in js_text)
    print("item-row in popup/index.js:", "item-row" in js_text)
    print("item-actions in popup/index.js:", "item-actions" in js_text)

with open('popup/index.css', 'r', encoding='utf-8') as f:
    css_text = f.read()
    print("plus-icon-container svg width: 38px in popup/index.css:", "38px" in css_text)
